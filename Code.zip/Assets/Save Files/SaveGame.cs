﻿using System;

[Serializable]
public abstract class SaveGame
{
}